﻿using System.Drawing;
using System.Windows.Forms;

namespace CST150W3A7 {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {

            this.calculateBtn = new Button();
            this.inputTxt = new TextBox();
            this.outputTxt = new TextBox();
            this.inputLbl = new Label();
            this.outputLbl = new Label();
            this.currentIterationLbl = new Label();
            this.progressBar = new ProgressBar();

            ///
            /// Form1
            /// 
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "π approximator";
            this.Size = new(350, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            AcceptButton = calculateBtn;
            this.SuspendLayout();
            ///
            /// calculateBtn
            ///
            this.calculateBtn.DialogResult = DialogResult.OK;
            this.calculateBtn.Size = new Size(75, 23);
            this.calculateBtn.Location = new Point(( 94 + 235 ) - 75+1, 64);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.Click += CalculateBtnOnClick;
            ///
            /// inputTxt
            ///
            this.inputTxt.Size = new(235,23);
            this.inputTxt.Location = new(94,12);
            this.inputTxt.Name = "inputTxt";
            this.inputTxt.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            ///
            /// outputTxt
            ///
            this.outputTxt.Size = new (235,23);
            this.outputTxt.Location = new(94,40);
            this.outputTxt.Name = "outputTxt";
            this.outputTxt.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            this.outputTxt.ReadOnly = true;
            ///
            /// inputLbl
            ///
            this.inputLbl.Text = "Terms:";
            this.inputLbl.Location = new Point(inputTxt.Location.X - (9 * inputLbl.Text.Length/2) - 12, 16);
            this.inputLbl.Name = "inputLbl";
            ///
            /// outputLbl
            ///
            this.outputLbl.Text = "Result:";
            this.outputLbl.Location = new Point(outputTxt.Location.X - (9 * outputLbl.Text.Length/2) - 10, 44);
            this.outputLbl.Name = "outputLbl";
            ///
            /// currentIterationLbl
            ///
            currentIterationLbl.Text = "%Iterations%";
            currentIterationLbl.AutoSize = true;
            currentIterationLbl.Location = new Point(9, 82);
            currentIterationLbl.Name = "currentIterationLbl";
            ///
            /// progressBar
            ///
            this.progressBar.Size = new(Width-2, 50);
            this.progressBar.Location = new(0, Bottom - progressBar.Height -10);
            this.progressBar.Style = ProgressBarStyle.Marquee;
            this.progressBar.Value = 50;
            this.progressBar.Visible = false;
            this.Controls.AddRange(new Control[] {calculateBtn, inputTxt, outputTxt, inputLbl, outputLbl, currentIterationLbl, progressBar});
            this.ResumeLayout(false);
        }

        #endregion

        private Button calculateBtn;
        private TextBox inputTxt;
        private TextBox outputTxt;
        private Label inputLbl;
        private Label outputLbl;
        private Label currentIterationLbl;
        private ProgressBar progressBar;
    }
}